export class PowerUp {
}
